
package hotelmanagementsystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;



public class DashBoard extends JFrame  implements ActionListener {
    DashBoard(){
        setLayout(null);
        setBounds(0,0,1550,1460);
        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/icons/third.jpg"));
        Image img=i1.getImage();
        Image scaledImg=img.getScaledInstance(1550, 1460, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon=new ImageIcon(scaledImg);
        JLabel lebel=new JLabel(scaledIcon);
        lebel.setBounds(0,0,1550,1000);
        add(lebel);
        JLabel text =new JLabel ("WELCOME!");
        text.setBounds(600,80,1000,70);
        lebel.add(text);
       
        
    /****/ JMenuItem reception =new JMenuItem("Reception");
        JMenuItem addEmp =new JMenuItem("Add Emplyee");
        JMenuItem addRoom =new JMenuItem("Add Rooms");
        
        
        text.setFont(new Font("Arial",Font.BOLD,60));
        text.setForeground(Color.white);
        JMenuBar mb=new JMenuBar();
        mb.setBounds(0,0,1550,80);
        lebel.add(mb);
        // MenuBar 
        JMenu hotel =new JMenu("Hotel Management");
        hotel.add(reception);
        
        mb.add(hotel);
        hotel.setForeground(Color.green);
        
        //MenuBar for Admin
        JMenu admin =new JMenu("Admin");
        admin.add(addEmp);
        admin.add(addRoom);
        mb.add(admin);
        admin.setForeground(Color.red);
        
        
        
        
        
        JButton button = new JButton("Rooms");
    button.setForeground(Color.white);
    button.setFont(new Font("Arial",Font.PLAIN,15));
    button.setBounds(180,30,120,20);
    button.setBackground(Color.green);
    add(button);
    button.addActionListener(this);
        
        
        
        setVisible(true);
        
//        while(true){
//         text.setVisible(false);
//         try{
//             Thread.sleep(500);
//         }
//         catch(Exception e){}
//         text.setVisible(true);
//         try{
//             Thread.sleep(500);
//         }
//         catch(Exception e){}         
//     }
    }
    @Override
     public void actionPerformed(ActionEvent ae){
        setVisible(false);
        new Rooms();
     }
    
    public static void main(String[] args){
        new DashBoard();
    }
}
