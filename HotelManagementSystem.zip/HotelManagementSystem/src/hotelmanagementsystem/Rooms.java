
package hotelmanagementsystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.*;
public class Rooms extends JFrame implements ActionListener{
    JTable table;
    JButton cancel;
    Rooms(){
        setBounds(300,200,1050,600);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/icons/hotel.jpg"));
        Image img=i1.getImage();
        Image scaledImg=img.getScaledInstance(600   , 600, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon=new ImageIcon(scaledImg);
        JLabel lebel=new JLabel(scaledIcon);
        lebel.setBounds(500,0,600,600);
        add(lebel);
        
        
        JLabel l1=new JLabel("Room NO.");
        l1.setBounds(5,10,100,20);
        add(l1);
        
        JLabel l2=new JLabel("Status");
        l2.setBounds(120,10,100,20);
        add(l2);
        
        JLabel l3=new JLabel("Price");
        l3.setBounds(250,10,100,20);
        add(l3);
        
        JLabel l4=new JLabel("Bed Type");
        l4.setBounds(380,10,100,20);
        add(l4);
        
        
        
        
       cancel=new JButton("Close");
        cancel.setBounds(180,350,120,30);
        add(cancel);
        cancel.addActionListener(this);
        cancel.setBackground(Color.black);
        cancel.setForeground(Color.white);

        
        table=new JTable();
        table.setBounds(0,40,500,400);
        add(table);
        try{
            Conn c= new Conn();
            ResultSet rs=c.s.executeQuery("Select * from room");
            table.setModel(DbUtils.resultSetToTableModel(rs));
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        
        
        
        setVisible(true);
    }
    
    @Override
     public void actionPerformed(ActionEvent ae){
        setVisible(false);
        new DashBoard();
        
    }
    
     
    public static void main(String[] args){
        new Rooms();
    }
    
}
