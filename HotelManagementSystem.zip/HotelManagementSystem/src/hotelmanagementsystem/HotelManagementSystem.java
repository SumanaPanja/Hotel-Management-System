
package hotelmanagementsystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;




public class HotelManagementSystem extends JFrame implements ActionListener{
    HotelManagementSystem(){
       
    setSize(1366,565);
    setLocation(100,100);
   
    ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icons/icons/first.jpg"));
    JLabel image = new JLabel(i1);
    JLabel text= new JLabel("HOTEL MANAGEMENT SYSTEM");
    text.setBounds(50,430,1000,50);
    
    image.add(text);
    text.setForeground(Color.WHITE);
    text.setFont(new Font("Arial",Font.ITALIC,50));
    JButton button = new JButton("Next");
    button.setForeground(Color.cyan);
    button.setFont(new Font("Arial",Font.BOLD,35));
    button.setBounds(1150,450,140,50);
    button.setBackground(Color.white);
    button.addActionListener(this);
    image.add(button);
    
    setLayout(null);
    image.setBounds(0,0,1366,565);
    add(image);
     setVisible(true);
     while(true){
         text.setVisible(false);
         try{
             Thread.sleep(500);
         }
         catch(Exception e){}
         text.setVisible(true);
         try{
             Thread.sleep(500);
         }
         catch(Exception e){}         
     }
     
    }
    
    public void actionPerformed(ActionEvent ae){
        setVisible(false);
        new Login();
        
    }
    
    public static void main(String[] args) {
        new HotelManagementSystem();
    }
    
}
