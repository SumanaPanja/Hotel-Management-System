
package hotelmanagementsystem;
import java.awt.Color;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class AddEmployee extends JFrame implements ActionListener{
    JLabel name,email,phone,age,gender,job,salary;
    JTextField tf,ag,sal,ph,em;
    JRadioButton rbm,rbf;
    JButton submit;
    JComboBox cb;
    AddEmployee(){
        
        setLayout(null);
         name=new JLabel("Name");
        name.setBounds(60,30,120,30);
        name.setFont(new Font("Tahoma",Font.PLAIN,18));
        add(name);
        
         tf = new JTextField();
        tf.setBounds(190,30,150,30);
        add(tf);
        
         age=new JLabel("Age");
        age.setBounds(60,80,120,30);
        age.setFont(new Font("Tahoma",Font.PLAIN,18));
        add(age);
        
         ag = new JTextField();
        ag.setBounds(190,80,150,30);
        add(ag);
        
          gender=new JLabel("Gender");
        gender.setBounds(60,130,120,30);
        gender.setFont(new Font("Tahoma",Font.PLAIN,18));
        add(gender);
        
         rbm =new JRadioButton("Male");
        rbm.setBounds(200,130,70,30);
        rbm.setFont(new Font("Tahoma",Font.PLAIN,14 ));
        rbm.setBackground(Color.white);
        add(rbm);
        
         rbf =new JRadioButton("Female");
        rbf.setBounds(280,130,70,30);
        rbf.setFont(new Font("Tahoma",Font.PLAIN,14 ));
        rbf.setBackground(Color.white);
        add(rbf);
        
        ButtonGroup bg= new ButtonGroup();
        bg.add(rbm);
        bg.add(rbf);
        
         job=new JLabel("Job");
        job.setBounds(60,180,120,30);
        job.setFont(new Font("Tahoma",Font.PLAIN,18));
        add(job);
        
        //Dropdown
        String str[]={"Manager","Accountant","Waiter","House Keeping","Chefs","Room Service","Kitchen Staff"};
        
        
         cb =new JComboBox(str);
        cb.setBounds(190,180,150,30);
        cb.setBackground(Color.white);
        add(cb);
        
         salary=new JLabel("Salary");
        salary.setBounds(60,230,120,30);
        salary.setFont(new Font("Tahoma",Font.PLAIN,18));
        add(salary);
        
        sal = new JTextField();
        sal.setBounds(190,230,150,30);
        add(sal);
        
         phone=new JLabel("Phone");
        phone.setBounds(60,270,120,30);
        phone.setFont(new Font("Tahoma",Font.PLAIN,18));
        add(phone);
        
         ph = new JTextField();
        ph.setBounds(190,270,150,30);
        add(ph);
        
        email=new JLabel("Email");
        email.setBounds(60,310,120,30);
        email.setFont(new Font("Tahoma",Font.PLAIN,18));
        add(email);
        
         em = new JTextField();
        em.setBounds(190,310,150,30);
        add(em);
        
        setBounds(150,200,850,540);
        getContentPane().setBackground(Color.white);
        
        submit=new JButton("Submit");
        submit.setBackground(Color.black);
        submit.setForeground(Color.white);
        submit.setBounds(250,430,159,30);
        add(submit);
        submit.addActionListener(this); 
        
        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icons/icons/tenth.jpg"));
        
        Image i2= i1.getImage();
        Image i3=i2.getScaledInstance(450, 450, Image.SCALE_DEFAULT);
        ImageIcon icon=new ImageIcon(i3);
        JLabel label =new JLabel(icon);
        label.setBounds(350,60,450,370); 
        add(label);
        
        
        
        
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent ae){
        String name=tf.getText();
        String age= ag.getText();
        String salary=sal.getText();
        String phone=ph.getText();
        String email= em.getText();
        
        String gender =null;
         if(rbm.isSelected())   {
         gender="Male";
}        else if(rbf.isSelected()) {
         gender="Female";
} 
         String job=(String)cb.getSelectedItem();
         try{
             Conn conn= new Conn();
             String query="insert into employee values('"+name+"','"+age+"','"+gender+"','"+job+"','"+salary+"','"+phone+"','"+email+"')";
             conn.s.executeUpdate(query);
             JOptionPane.showMessageDialog(null,"Employee added Successfully");
             setVisible(false);                 
         }catch(Exception e){
             e.printStackTrace();
         }
        
        
    }
    public static void main(String[] args){
        new AddEmployee();
    }
    
}
