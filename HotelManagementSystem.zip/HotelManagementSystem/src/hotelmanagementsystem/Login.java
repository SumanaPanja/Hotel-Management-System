
package hotelmanagementsystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class Login extends JFrame implements ActionListener {
    JTextField userName;
    JPasswordField password;
    JButton login, cancel;
    Login(){
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);
        setBounds(200,200,600,300);
        
        JLabel user= new JLabel("User Name");
        user.setBounds(40, 30, 100, 30);
        add(user);
         userName =new JTextField();
        userName.setBounds(150,30,150,30);
        add(userName);
        
        
        JLabel pass= new JLabel("Password");
        pass.setBounds(40, 90, 100, 30);
        add(pass);
         password =new JPasswordField();
        password.setBounds(150,90,150,30);
        add(password);
        
        
        //Login Button
         login=new JButton("Login");
        login.setBounds(40,150,120,30);
        login.addActionListener(this);
        add(login);
        login.setBackground(Color.black);
        login.setForeground(Color.white);
        
        
        //Cancel button
         cancel=new JButton("Cancel");
        cancel.setBounds(180,150,120,30);
        add(cancel);
        cancel.addActionListener(this);
        cancel.setBackground(Color.black);
        cancel.setForeground(Color.white);
        
        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/icons/second.jpg"));
        Image img=i1.getImage();
        Image scaledImg=img.getScaledInstance(200, 200, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon=new ImageIcon(scaledImg);
        JLabel lebel=new JLabel(scaledIcon);
        lebel.setBounds(350,10,200,200);
        
        add(lebel);
       
        setVisible(true); 
        
    }
    @Override
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==login){
            String user=userName.getText();
            String pass=password.getText();
            try{
                Conn c= new Conn();
                String query="Select * from login where username='"+user+"' and password='"+pass+"'";
                ResultSet rs=c.s.executeQuery(query);
                if(rs.next()){
                    setVisible(false);
                    new DashBoard();
                    
                }else{
                    JOptionPane.showMessageDialog(null,"Invalid Username or Password");
                    setVisible(false);
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
            
        }
        else if(ae.getSource()==cancel){
            setVisible(false);
        }
        
    }
    public static void main(String[] args){
        new Login();
    }
}
